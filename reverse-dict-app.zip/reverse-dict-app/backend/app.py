"""
Reverse Dictionary backend API.

Serves a small REST API on localhost that the Gradle/Spring Boot frontend
calls. Wraps the encoders already in this project:

  - "sif"                 -> sif_query.py (always available, sklearn only)
  - "sentence-transformer" -> sentence_transformer_encoder.py (needs the
                              `sentence-transformers` package)
  - "bert-cls"             -> bert_cls.py (needs `torch` + `transformers`)

Run:
    pip install -r requirements.txt
    uvicorn app:app --host 0.0.0.0 --port 8000

Endpoints:
    GET  /api/encoders            -> which encoders are available right now
    POST /api/query                {"text": "...", "encoder": "sif", "top_k": 10}
    GET  /api/health
"""

from __future__ import annotations

import os
import sys
import time
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Paths / config
# ---------------------------------------------------------------------------

PROJECT_DIR = Path(os.environ.get("REVDICT_DATA_DIR", "/mnt/project"))
sys.path.insert(0, str(PROJECT_DIR))

import sif_query  # noqa: E402  (from the project directory)

DEFAULT_TOP_K = 10
MAX_TOP_K = 500
SIF_SUBSET_FRAC = float(os.environ.get("REVDICT_SIF_SUBSET_FRAC", "0.25"))


def _pick_data_path() -> Path:
    """Prefer opted_train.csv (as sif_query.py expects); fall back to
    whatever processed OPTED split files are actually present so the demo
    still works if only test/valid were exported into this environment."""
    candidates = [
        PROJECT_DIR / "opted_train.csv",
        PROJECT_DIR / "opted_valid.csv",
        PROJECT_DIR / "opted_test.csv",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        "No processed OPTED split (opted_train/valid/test.csv) found under "
        f"{PROJECT_DIR}. Set REVDICT_DATA_DIR to the folder containing them."
    )


DATA_PATH = _pick_data_path()

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(title="Reverse Dictionary API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # local demo only
    allow_methods=["*"],
    allow_headers=["*"],
)


class QueryRequest(BaseModel):
    text: str = Field(..., min_length=1, description="Definition-style query text")
    encoder: str = Field("sif", description="sif | sentence-transformer | bert-cls")
    top_k: int = Field(DEFAULT_TOP_K, ge=1, le=MAX_TOP_K)


class ResultRow(BaseModel):
    rank: int
    word: str
    definition: str
    score: float


class QueryResponse(BaseModel):
    encoder: str
    top_k: int
    took_ms: float
    results: list[ResultRow]


# ---------------------------------------------------------------------------
# SIF encoder: built once at startup, always available (sklearn only)
# ---------------------------------------------------------------------------

print(f"Building SIF index from {DATA_PATH} (subset_frac={SIF_SUBSET_FRAC}) ...")
_sif_index = sif_query.build_sif_index(
    data_path=DATA_PATH,
    subset_frac=SIF_SUBSET_FRAC,
    random_seed=42,
    embedding_dim=100,
    max_features=30000,
    sif_a=1e-3,
)
print(
    f"SIF index ready: {_sif_index['subset_rows']:,} rows, "
    f"{len(_sif_index['candidate_words']):,} candidate words."
)

# ---------------------------------------------------------------------------
# Optional neural encoders, loaded lazily on first use so the server still
# starts cleanly if torch / sentence-transformers / transformers aren't
# installed.
# ---------------------------------------------------------------------------

_neural_state: dict[str, dict] = {}


def _load_neural_encoder(encoder_name: str):
    """Lazily build (encoder, candidate_df, candidate_embeddings) for a
    neural encoder and cache it. Raises HTTPException if the required
    package isn't installed."""
    if encoder_name in _neural_state:
        return _neural_state[encoder_name]

    df = pd.read_csv(DATA_PATH, dtype=str, keep_default_na=False)
    # Keep the candidate pool aligned with the SIF index size so responses
    # come back in reasonable time on CPU.
    if len(df) > 20000:
        df = df.sample(n=20000, random_state=42).reset_index(drop=True)

    candidate_df = df.drop_duplicates(subset=["word_norm"]).reset_index(drop=True)

    if encoder_name == "sentence-transformer":
        try:
            from sentence_transformer_encoder import SentenceTransformerEncoder
        except ImportError as exc:
            raise HTTPException(
                status_code=503,
                detail=(
                    "sentence-transformers is not installed on the backend. "
                    "Run: pip install sentence-transformers"
                ),
            ) from exc
        encoder = SentenceTransformerEncoder(
            model_name=os.environ.get(
                "REVDICT_ST_MODEL", "sentence-transformers/all-MiniLM-L6-v2"
            )
        )
    elif encoder_name == "bert-cls":
        try:
            from bert_cls import BertClsEncoder
        except ImportError as exc:
            raise HTTPException(
                status_code=503,
                detail=(
                    "torch/transformers are not installed on the backend. "
                    "Run: pip install torch transformers"
                ),
            ) from exc
        encoder = BertClsEncoder(
            model_name=os.environ.get("REVDICT_BERT_MODEL", "bert-base-uncased")
        )
    else:
        raise HTTPException(status_code=400, detail=f"Unknown encoder: {encoder_name}")

    print(f"Encoding {len(candidate_df):,} candidate definitions with {encoder_name} ...")
    candidate_embeddings = encoder.encode(
        candidate_df["definition_original"].tolist(), batch_size=32
    )
    norms = np.linalg.norm(candidate_embeddings, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    candidate_embeddings_norm = (candidate_embeddings / norms).astype(np.float32)

    state = {
        "encoder": encoder,
        "candidate_df": candidate_df,
        "candidate_embeddings_norm": candidate_embeddings_norm,
    }
    _neural_state[encoder_name] = state
    return state


def _query_neural(encoder_name: str, text: str, top_k: int) -> pd.DataFrame:
    state = _load_neural_encoder(encoder_name)
    query_embedding = state["encoder"].encode([text], batch_size=1)
    norm = np.linalg.norm(query_embedding, axis=1, keepdims=True)
    norm[norm == 0] = 1.0
    query_embedding_norm = (query_embedding / norm).astype(np.float32)

    scores = (query_embedding_norm @ state["candidate_embeddings_norm"].T).ravel()
    top_indices = np.argsort(-scores)[:top_k]

    results = state["candidate_df"].iloc[top_indices][
        ["word_original", "definition_original"]
    ].copy()
    results.insert(0, "rank", np.arange(1, len(results) + 1))
    results["score"] = scores[top_indices]
    return results


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@app.get("/api/health")
def health():
    return {"status": "ok", "data_path": str(DATA_PATH)}


@app.get("/api/encoders")
def list_encoders():
    """Report which encoders are currently usable without triggering a
    heavy load, so the frontend dropdown can grey out unavailable ones."""

    def _installed(module_name: str) -> bool:
        try:
            __import__(module_name)
            return True
        except ImportError:
            return False

    return {
        "encoders": [
            {"id": "sif", "label": "SIF (baseline, always on)", "available": True},
            {
                "id": "sentence-transformer",
                "label": "Sentence-Transformer",
                "available": _installed("sentence_transformers"),
            },
            {
                "id": "bert-cls",
                "label": "BERT [CLS]",
                "available": _installed("transformers") and _installed("torch"),
            },
        ]
    }


@app.post("/api/query", response_model=QueryResponse)
def query(request: QueryRequest):
    started = time.perf_counter()
    encoder_name = request.encoder.strip().lower()

    if encoder_name == "sif":
        try:
            results_df = sif_query.query_sif(_sif_index, request.text, request.top_k)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        word_col = "word_original"
    elif encoder_name in ("sentence-transformer", "bert-cls"):
        results_df = _query_neural(encoder_name, request.text, request.top_k)
        word_col = "word_original"
    else:
        raise HTTPException(
            status_code=400,
            detail="encoder must be one of: sif, sentence-transformer, bert-cls",
        )

    took_ms = (time.perf_counter() - started) * 1000
    results = [
        ResultRow(
            rank=int(row["rank"]),
            word=str(row[word_col]),
            definition=str(row["definition_original"]),
            score=float(row["score"]),
        )
        for _, row in results_df.iterrows()
    ]

    return QueryResponse(
        encoder=encoder_name,
        top_k=request.top_k,
        took_ms=round(took_ms, 1),
        results=results,
    )
