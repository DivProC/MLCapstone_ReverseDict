package com.revdict.frontend;

import java.util.List;

public class QueryDtos {

    public record QueryRequest(String text, String encoder, int topK) {}

    public record ResultRow(int rank, String word, String definition, double score) {}

    public record QueryResponse(
            String encoder, int topK, double tookMs, List<ResultRow> results) {}
}
