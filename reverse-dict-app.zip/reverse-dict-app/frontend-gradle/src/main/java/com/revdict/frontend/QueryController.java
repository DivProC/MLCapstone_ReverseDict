package com.revdict.frontend;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

/**
 * Thin proxy in front of the Python reverse-dictionary API so the browser
 * only ever talks to this Spring Boot app (avoids CORS entirely and keeps
 * the Python service address out of client-side JS).
 */
@RestController
@RequestMapping("/api")
public class QueryController {

    private final WebClient client;

    public QueryController(WebClient revdictApiClient) {
        this.client = revdictApiClient;
    }

    @GetMapping(value = "/encoders", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<String>> encoders() {
        return client
                .get()
                .uri("/api/encoders")
                .exchangeToMono(this::passthrough);
    }

    @GetMapping(value = "/health", produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<String>> health() {
        return client
                .get()
                .uri("/api/health")
                .exchangeToMono(this::passthrough);
    }

    @PostMapping(
            value = "/query",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<ResponseEntity<String>> query(@RequestBody String rawJsonBody) {
        return client
                .post()
                .uri("/api/query")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(rawJsonBody)
                .exchangeToMono(this::passthrough);
    }

    private Mono<ResponseEntity<String>> passthrough(
            org.springframework.web.reactive.function.client.ClientResponse response) {
        HttpStatusCode status = response.statusCode();
        return response
                .bodyToMono(String.class)
                .defaultIfEmpty("{}")
                .map(body -> ResponseEntity.status(status)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(body));
    }
}
