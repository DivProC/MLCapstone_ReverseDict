package com.revdict.frontend;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    // Where the Python (FastAPI) reverse-dictionary service is running.
    // Override with -Drevdict.api.base-url=... or the Gradle property
    // revdictApiBase (see build.gradle).
    @Value("${revdict.api.base-url:http://localhost:8000}")
    private String apiBaseUrl;

    @Bean
    public WebClient revdictApiClient() {
        return WebClient.builder().baseUrl(apiBaseUrl).build();
    }
}
